/*************************************************************************************
  ��			  �� :  ��ũ���� ������ �׷��� ��� Ŭ����.

  ����			���� :	�� Ŭ������ �������� ��� ���� ������ε� �����ϴ°��� ���մϴ�.
						
  �ʿ�	  ���̺귯�� :	ddraw.lib<ddraw.h>,dxguid.lib

  �ۼ�			��¥ :	98.12.03����..
  ù��°		���� :	98.12.09~
  ����°		���� :	99.01.06~
						�Լ� �����͸� �̿���..
  �׹�°		���� :	99.06.06~
						����ȿ�� �߰�(�� ����..) �Ѱ�.. ����ȭ..

	xxxxx	Normal				:	�ƹ��� ��ȯ ���� �� ����ش�.
	xxxxxHB Half	Blending	:	�̹����� ����� �ݹ� ���´�.
	xxxxxAB Alpha	Blending	:	�̹����� ����� ������ ������ ���´�.
	xxxxxFX						:	...���� ���ڳ�.. ==; ���� ����ó���� �������� ȿ����..

*************************************************************************************/

#ifndef _classDRAW_H_
#define _classDRAW_H_

#include <windows.h>

#include "SFC.H"

#define	d4HM_MASK				0x7bde7bde
#define	d2HM_MASK				0x7bde
#define	d4AM_MASK_1				0x7c1f03e0
#define	d4AM_MASK_2				0x03e07c1f

#define	dGET_RED_SHIFT			10
#define	dGET_GREEN_MASK			31

extern	WORD					redEFFECT[7][32][32];
extern	WORD					blueEFFECT[7][32][32];
extern	WORD					greenEFFECT[7][64][64];

typedef struct
{	int	pos;
	int	size;
} zoomTable;

extern zoomTable	zoomXTable[3096];
extern zoomTable	zoomYTable[3096];
extern inline void	MakeSpriteRTable(int x,int y,int xs,int ys,int xLen,int yLen);
extern inline void	fMakeSpriteRTable(int x,int y,int xs,int ys,int xLen,int yLen);

class cDRAW
{
public:
	static int					WIDTH,HEIGHT,halfScreen,halfWidth,byteWidth,dotPerScreen,bytePerScreen;
	static WORD					*p2SCREEN;
	static UINT					*p4SCREEN;

	static BOOL	Init			();
	static BOOL	Active			(WORD *screen,int width,int height);

	static void	PutPixel		(WORD color,int x,int y);

	static void	Line			(WORD color,int x1,int y1,int x2,int y2);
	static void	XLine			(WORD color,int x1,int x2,int y,int thick=1);
	static void	YLine			(WORD color,int y1,int y2,int x,int thick=1);
	static void	XLineAB			(WORD color,int alpha,int x1,int x2,int y,int thick=1);
	static void	YLineAB			(WORD color,int alpha,int y1,int y2,int x,int thick=1);
	static void	XLineHB			(WORD color,int x1,int x2,int y,int thick=1);
	static void	YLineHB			(WORD color,int y1,int y2,int x,int thick=1);
	static void	Box				(WORD color,int x1,int y1,int x2,int y2,int thick=1);
	static void	BoxAB			(WORD color,int alpha,int x1,int y1,int x2,int y2,int thick=1);
	static void	BoxHB			(WORD color,int x1,int y1,int x2,int y2,int thick=1);

/*	16bit	ȭ�� ü���								*/
	static void	Clear			();
	static void	Fill			(WORD color);
	static void	FillHB			(WORD color);
	static void	FillAB			(WORD color,int alpha);

/*	16bit	���� ü���.. �ڽ���..					*/
	static void	Fill			(WORD color,int x1,int y1,int x2,int y2);
	static void	FillHB			(WORD color,int x1,int y1,int x2,int y2);
	static void	FillAB			(WORD color,int x1,int y1,int x2,int y2,int alpha);

/*	16bit	�̹��� �о� ����..						*/
	static void GetImage		(int x,int y,int xs,int ys,WORD *img);
	static WORD*GetImage		(int x,int y,int xs,int ys);

/*	16bit	�̹��� ����ֱ�..						*/
	static void	PutImage		(int x,int y,WORD *img);
	static void	PutImageHB		(int x,int y,WORD *img);
	static void	PutImageAB		(int x,int y,WORD *img,int alpha);

/*	8bit	�̹��� ����ֱ�..						*/
	static void	PutImage		(int x,int y,BYTE *img,WORD *plt);
	static void	PutImageHB		(int x,int y,BYTE *img,WORD *plt);
	static void	PutImageAB		(int x,int y,BYTE *img,WORD *plt,int alpha);

/*	���� font	��� Ŭ����..	*/
	static void	PutFontNormal	(int x,int y,WORD color,BYTE *font,BOOL bMC);
	static void	PutFontHB		(int x,int y,WORD color,BYTE *font,BOOL bMC);
	static void	PutFont			(int x,int y,WORD color,BYTE *font,int alpha,BOOL bMC);

/*	�׸���	���..				*/
	static void PutShadow		(int x,int y,BYTE *shadow);
	static void	PutShadowR		(int x,int y,BYTE *sprite,int xRate,int yRate);
	static void	fPutShadowR		(int x,int y,BYTE *sprite,int xRate,int yRate);

	static void	PutLayer		(int x,int y,WORD color,BYTE *sprite);
	static void	fPutLayer		(int x,int y,WORD color,BYTE *sprite);
	static void	PutLayerR		(int x,int y,WORD color,BYTE *sprite,int xRate,int yRate);
	static void	fPutLayerR		(int x,int y,WORD color,BYTE *sprite,int xRate,int yRate);

	static void	AA				(int x,int y,int xs,int ys);				//	��Ƽ ����̽�
	static void	AA				(int x,int y,int xs,int ys,WORD color);
};

class c8BITSPRITE	: public cDRAW
{
public:
	static void	PutSprite		(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	PutSpriteColor	(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	PutSpriteHB		(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	PutSpriteAB		(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	PutSpriteFX		(int x,int y,BYTE *sprite,WORD *plt,int fx);

	static void	fPutSprite		(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	fPutSpriteColor	(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	fPutSpriteHB	(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	fPutSpriteAB	(int x,int y,BYTE *sprite,WORD *plt,int alpha);
	static void	fPutSpriteFX	(int x,int y,BYTE *sprite,WORD *plt,int fx);

	static void	PutSpriteR		(int x,int y,BYTE *sprite,WORD *plt,int xrate,int yrate,int alpha);
	static void	PutSpriteRColor	(int x,int y,BYTE *sprite,WORD *plt,int xRate,int yRate,int alpha);
	static void	PutSpriteRHB	(int x,int y,BYTE *sprite,WORD *plt,int xrate,int yrate,int alpha);
	static void	PutSpriteRAB	(int x,int y,BYTE *sprite,WORD *plt,int xrate,int yrate,int alpha);
	static void	PutSpriteRFX	(int x,int y,BYTE *sprite,WORD *plt,int xrate,int yrate,int fx);

	static void	fPutSpriteR		(int x,int y,BYTE *sprite,WORD *plt,int xRate,int yRate,int alpha);
	static void	fPutSpriteRColor(int x,int y,BYTE *sprite,WORD *plt,int xRate,int yRate,int alpha);
	static void	fPutSpriteRHB	(int x,int y,BYTE *sprite,WORD *plt,int xRate,int yRate,int alpha);
	static void	fPutSpriteRAB	(int x,int y,BYTE *sprite,WORD *plt,int xRate,int yRate,int alpha);
	static void	fPutSpriteRFX	(int x,int y,BYTE *sprite,WORD *plt,int xRate,int yRate,int fx);
};

class c16BITSPRITE	: public cDRAW
{
public:
	static void	PutSprite		(int x,int y,WORD *sprite,int alpha);
	static void	PutSpriteColor	(int x,int y,WORD *sprite,int alpha);
	static void	PutSpriteHB		(int x,int y,WORD *sprite,int alpha);
	static void	PutSpriteAB		(int x,int y,WORD *sprite,int alpha);
	static void	PutSpriteFX		(int x,int y,WORD *sprite,int fx);

	static void	fPutSprite		(int x,int y,WORD *sprite,int alpha);
	static void	fPutSpriteColor	(int x,int y,WORD *sprite,int alpha);
	static void	fPutSpriteHB	(int x,int y,WORD *sprite,int alpha);
	static void	fPutSpriteAB	(int x,int y,WORD *sprite,int alpha);
	static void	fPutSpriteFX	(int x,int y,WORD *sprite,int fx);

	static void	PutSpriteR		(int x,int y,WORD *sprite,int xrate,int yrate,int alpha);
	static void	PutSpriteRColor	(int x,int y,WORD *sprite,int xrate,int yrate,int alpha);
	static void	PutSpriteRHB	(int x,int y,WORD *sprite,int xrate,int yrate,int alpha);
	static void	PutSpriteRAB	(int x,int y,WORD *sprite,int xrate,int yrate,int alpha);
	static void	PutSpriteRFX	(int x,int y,WORD *sprite,int xrate,int yrate,int fx);

	static void	fPutSpriteR		(int x,int y,WORD *sprite,int xRate,int yRate,int alpha);
	static void	fPutSpriteRColor(int x,int y,WORD *sprite,int xRate,int yRate,int alpha);
	static void	fPutSpriteRHB	(int x,int y,WORD *sprite,int xRate,int yRate,int alpha);
	static void	fPutSpriteRAB	(int x,int y,WORD *sprite,int xRate,int yRate,int alpha);
	static void	fPutSpriteRFX	(int x,int y,WORD *sprite,int xRate,int yRate,int fx);
};

extern	void	(*PutSprite16[22])	(int x,int y,WORD *sprite,int alpha);
extern	void	(*PutSpriteR16[22])	(int x,int y,WORD *sprite,int xRate,int yRate,int alpha);
extern	void	(*PutSprite8[22])	(int x,int y,BYTE *sprite,WORD *plt,int alpha);
extern	void	(*PutSpriteR8[22])	(int x,int y,BYTE *sprite,WORD *plt,int xRate,int yRate,int alpha);
extern	void	(*PutFont[3])		(int x,int y,WORD color,int alpha,BYTE *font,BOOL bMC);

extern	BOOL	CONVERTSPRITE(WORD *sprite);
extern	BOOL	CONVERTIMAGE(WORD *image);
extern	BOOL	CONVERTPALETTE(WORD *plt,int range);

extern	WORD	*CONVERT24TO16(BYTE *buffer,int xs,int ys);
extern	WORD	*CONVERT24TO16(BYTE *buffer,BYTE *plt,int xs,int ys);
extern	BYTE	*CONVERT16TO24(WORD *buffer);
extern	WORD	*CONVERTPALETTE(BYTE *plt);

extern	inline	WORD	RGB24ToRGB565(int r,int g,int b);
extern	inline	WORD	RGB24ToRGB555(int r,int g,int b);
extern	inline	WORD	RGB24ToBGR565(int r,int g,int b);
extern	inline	WORD	RGB24To16(int r,int g,int b);
extern	inline	void	RGB16To24(WORD color,BYTE &r,BYTE &g,BYTE &b);
extern	inline	WORD	RGB565ToBGR565(WORD color);
extern	inline	WORD	RGB565ToRGB555(WORD color);
extern	inline	WORD	CONVERTPIXEL(WORD color);

extern	inline	DWORD	MIX4BYTE(DWORD spriteColor,DWORD screenColor,int alpha,int dest_alpha);
extern	inline	DWORD	fMIX4BYTE(DWORD spriteColor,DWORD screenColor,int alpha,int dest_alpha);
extern	inline	WORD	MIX2BYTE(WORD spriteColor,WORD screenColor,int alpha,int dest_alpha);
extern	inline	WORD	FXMIX(WORD spriteColor,WORD screenColor,int effect);


#define dRGB565		0 
#define dRGB555		1
#define dBGR565		2

#define dYELLOW		0
#define dCYAN		1
#define dRED		2
#define dGREEN		3
#define dGRAY		4 
#define dBLUE		5
#define dPURPLE		6

extern	WORD		_WHITE		,_BLACK;
extern	WORD		_LTGRAY		,_GRAY		,_DEEPGRAY;
extern	WORD		_LTCYAN		,_CYAN		,_DEEPCYAN;
extern	WORD		_LTBLUE		,_BLUE		,_DEEPBLUE;
extern	WORD		_LTRED		,_RED		,_DEEPRED;
extern	WORD		_LTGREEN	,_GREEN		,_DEEPGREEN;
extern	WORD		_LTYELLOW	,_YELLOW	,_DEEPYELLOW;
extern	WORD		_LTPURPLE	,_PURPLE	,_DEEPPURPLE;

/*		�׶��̼� �÷� ����Ÿ..	*/
extern	WORD		_gCOL[7][16];

#endif